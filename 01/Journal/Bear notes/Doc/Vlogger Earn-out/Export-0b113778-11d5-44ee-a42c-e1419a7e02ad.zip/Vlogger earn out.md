# Vlogger earn-out

Edited: Sep 04, 2019 12:24 PM
Tags: vlogger

## Schedule 4 of SPA

![Vlogger%20earn%20out/Untitled.png](Vlogger%20earn%20out/Untitled.png)

## Earn-out consideration

Vlogger: Earn-Out Consideration in respect of a financial year shall be payable by thePurchaser to the Seller if the following earn-out targets of such financial year are met(the "Earn-Out Targets").

The Company's audited consolidated financial results for the relevant financial year meetall of the three applicable earn-out targets as set out in the below table of the relevantfinancial year (in terms of revenue, EBITDA and Free Cash Flow), as may be adjusted byagreement in writing between the Seller and the Purchaser:

Pic1 

---

provided that:

(a) revenue from any direct or indirect subsidiary of PCCW Limited ("PCCW") excluding the Company and the Subsidiaries but including HKT Limited and its members (together, "PCCW Group") and PCCW's connected persons (as defined by the Rules Governing The Listing Rules of Of Securities On The Stock Exchange ofOf Hong Kong Limited, the "Listing Rules") may only, in aggregate, contribute up to 20% of the revenue of the Company (before adjustment) for each financial year for the purposes of determining whether a revenue Earn-Out Target has been met, and any revenue from PCCW Group and PCCW's connected persons that exceeds 20% shall be disregarded for such relevant calculation of the aggregate revenue of the Company for that financial year;

----- 

## Earn-Out Consideration

payment =(0.51 x Relevant Financial Year Company Value) – AccumulatedConsideration,where:"Relevant Financial Year Company Value" shall be derived by multiplying:

(i) 7.5 (the "EBITDA Multiple") by

(ii) the sum of EBITDA for the relevant financial year (as shown in the audited consolidated financial statements of the Company for the relevant financial year) and any Previous Year Excess ("EBITDA+PrevExcess"), provided that EBITDA+PrevExcess cannot be more than the 

Max EBITDA for the relevant financial year."Max EBITDA" means in each financial year of the Company:pic 

---

![Vlogger%20earn%20out/Untitled%201.png](Vlogger%20earn%20out/Untitled%201.png)

![Vlogger%20earn%20out/Untitled%202.png](Vlogger%20earn%20out/Untitled%202.png)

![Vlogger%20earn%20out/Untitled%203.png](Vlogger%20earn%20out/Untitled%203.png)

![Vlogger%20earn%20out/Untitled%204.png](Vlogger%20earn%20out/Untitled%204.png)